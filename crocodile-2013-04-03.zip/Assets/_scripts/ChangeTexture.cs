using UnityEngine;
using System.Collections;

public class ChangeTexture : MonoBehaviour {
public Texture2D t_static_tx = null;
public Texture2D t_dynamic_tx = null;
public WWW t_load = null;
        void OnEnable() {
                //DoChangeTexture();

        }


 
}