public static class tk2dMenu
{
	public const string root = "2D Toolkit/";
}
